package bombbot;

import java.io.BufferedReader;
import java.io.ByteArrayInputStream;
import java.io.IOException;
import java.io.InputStreamReader;
import java.util.Random;
import java.util.logging.Level;
import java.util.logging.Logger;

/**
 * @author Jaco
 */

/**  FUNCTIONALITY:
 *  How this works is all the players are initialized according to their name and starting position (x, y).
 *  After that, say the MiniMax tree looks like such:
 * 
 *              (a)             -> initial state
 *         /  /  |  \  \
 *       (b)(c) (d) (e)(f)      -> all opponent possible choices
 *      /\  /\  |||  /\  /\
 *     (.) (.)  (.)  (.) (.)    -> all my possible choices
 * 
 *  How the algorithm then looks is:
 *  (111):
 *  {
 *      1)  Create branches [b through to f in first case] containing possible opponent decisions based on context in parent (a)
 *          and how it will affect your Points (this is what is saved in MMNodes b to f)
 *      2)  For each branch:
 *     2.1) IF: Branch level = highest branch level and branch is parent's leftmost unprocessed branch (smallest index in MMNode 'children' array):
 *              + De-allocate temp Player state of current MMNode: restore = null;
 *              + Go to parent's next branch (Parent MMNode's children[current index + 1]) and do (111) again.
 *     2.2) ELSE IF: Branch level = highest branch level and branch is parent's rightmost unprocessed branch (largest index in MMNode 'children' array):
 *              + De-allocate temp Player state of current MMNode: restore = null;
 *              + Set parent as new child, and do (111) to rest of {new child}'s parent's smallest indexes in that 'children' array
 *     2.3) ELSE IF:  Branch level != highest branch level:
 *              + Create a temp state for each Player that will save their states: Player[] restore = players;      (used for backtracking)
 *              + Change current Player state to how it would be after the move that was calculated in (1): players = {updated player list}
 *              + GOTO (111)
 *  }
 * 
 *  Thus the how the MiniMax is built:
 *  - Create two public ActionAward arrays containing all actions YOU can take from original state (i.e the second level of the MiniMax Tree)
 *    and each is initialized with its corresponding values. (1) is persistent and the other is a temp.
 * 
 *  1) For each node, the children array is initialized with nulls. The leftmost child is the initiated and its children array is set to nulls.
 *     The first node of that children array is then initialized and so on until the children array of the Leftmost node in the second last level is
 *     initialized to nulls.
 * 
 *  2) IF one of the children array of possibilities is that a bomb explodes and hits YOU, the parent of that children array (will always be a YOU choice)
 *     must then be removed / deleted. THUS IT IS RECOMMENDED TO DETERMINE IF A BOMB BLOWING UP AND HITTING YOU IS A POSSIBILITY *FIRST*, BEFORE THE OTHER
 *     POSSIBILITIES.
 * 
 *  3) The reward for each node of the children array in the last level is calculated. The function goes to the parent of the children array and the
 *     largest (either largest + for YOUR move or - for ENEMY move) is added to the temp ActionAward. The children array is then de-allocated.
 */

// FIX BOMB PROBLEM: Add player bombs in initPlayer()
public class MiniMaxEnigine
{
    //Setting MiniMax with foresight of 15 moves MIGHT NEED TO CHANGE LATER TO ACCOMMODATE PROCESSING LIMITS
    
    //Actions for each player: L (Left), R (Right), U (Up), D (Down), PB (Plant Bomb), RBT (Reduce Bomb Time to 1), N (Nothing)
    //Bomb actions: DD (Destroy Destructable wall = 10p), HP (hit player = 50p), HB (Hit other bomb)
    
    private String context, playerStats;
    private MMNode root;
    
    private Player[] players;
    private Player me;
    
    private ActionAward allAwards = new ActionAward(new String[]{"N", "U", "L", "R", "D", "PB", "RBT"}, new int[]{0, 1, 1, 1, 1, 2, 1});
    private ActionAward yourAwards;         //saves all the moves YOU can return as answers AND each move's final weight
    
    //int tempAccumilator = 0;        //This is used as temporary reward save for yourAwards[current YOUR move num]
    private int bestAction = new Random().nextInt(6);         //Deafault is do nothing (do nothing = return nothing)
    private int maxLevel = 6;
    
    public MiniMaxEnigine(String _context, String _playerStats, char myName, int _level)
    {
        context = _context;     //map
        playerStats = _playerStats;
        me = new Player(myName);
        
        root = new MMNode(_level);
        initPlayers();
    }
    
    public MiniMaxEnigine(String _context, String _playerStats, char myName, int _level, int childNum)
    {
        context = _context;
        playerStats = _playerStats;
        me = new Player(myName);
        
        root = new MMNode(_level, childNum);
        initPlayers();
    }
    
    //Initialise each player in the game according to start pos
    private void initPlayers()
    {
        try
        {
            BufferedReader reader = new BufferedReader(new InputStreamReader(new ByteArrayInputStream(context.getBytes())));
            System.out.println(context);
            
            //reader.mark(1);
            String line;
            char name;
            int bBag;
            
            String[] temp = playerStats.split("\\n");       //temp.length = num lines, thus temp.length / 7 = num players
            
            players = new Player[(int)(temp.length / 7) - 1];
            int playerC = 0, x = 0, y;

            for (int i = 0; i < players.length + 1; i++)
            {
                //reader.reset();
                reader = new BufferedReader(new InputStreamReader(new ByteArrayInputStream(context.getBytes())));
                name = temp[(i * 7) + 1].toUpperCase().charAt(5);
                bBag = Integer.parseInt(temp[(i * 7) + 5].toUpperCase().substring(9, temp[(i * 7) + 5].toUpperCase().length()));
                
                //Get player pos on map
                for (y = 0; (line = reader.readLine()) != null; y++)
                {
                    line = line.toUpperCase();
                    if ((x = line.indexOf(name)) != -1)
                    {
                        break;
                    }
                }
                //System.out.println("Name: " + name + ", x = " + x + ", y = " + y);
                
                //ADD BOMBS PER PLAYER ACCORDING TO PLAYER STATS
                //IMPORTANT!!!!     BOMBS IN MAP ARE 1-INDEXED NOT 0 INDEXED, SO IF YOU READ THEM IN, MAKE THEM 0 INDEXED BY GOING Bomb(x - 1, y - 1, fuse, rad)
                line = temp[(i * 7) + 4];
                String[] bombsV = line.substring(7, line.length()).split(",");
                
                if (name == me.getName())
                {
                    me = new Player(name, x, y, Integer.parseInt(temp[(i * 7) + 6].substring(13, temp[(i * 7) + 6].length())), 0, bBag);
                    
                    //ADD BOMBS PER PLAYER ACCORDING TO PLAYER STATS
                    for (int j = 0; j < (int)(bombsV.length / 4); j++)
                    {
                        //Bomb(x - 1, y - 1, fuse, rad) to convert from map's 1-indexed to my 0-indexed
                        me.placeBomb(Integer.parseInt(bombsV[j + 0].substring(3, bombsV[j + 0].length())) - 1, Integer.parseInt(bombsV[j + 1].substring(2, bombsV[j + 1].length())) - 1, Integer.parseInt(bombsV[j + 2].substring(5, bombsV[j + 2].length())), Integer.parseInt(bombsV[j + 3].substring(7, bombsV[j + 3].length() - 1)));
                    }
                }
                else
                {
                    players[playerC] = new Player(name, x, y, Integer.parseInt(temp[(i * 7) + 6].substring(13, temp[(i * 7) + 6].length())), 0,  bBag);
                    
                    //ADD BOMBS PER PLAYER ACCORDING TO PLAYER STATS
                    for (int j = 0; j < bombsV.length - 1; j+=4)
                    {
                        //Bomb(x - 1, y - 1, fuse, rad) to convert from map's 1-indexed to my 0-indexed
                        players[playerC].placeBomb(Integer.parseInt(bombsV[j + 0].substring(3, bombsV[j + 0].length())) - 1, Integer.parseInt(bombsV[j + 1].substring(2, bombsV[j + 1].length())) - 1, Integer.parseInt(bombsV[j + 2].substring(5, bombsV[j + 2].length())), Integer.parseInt(bombsV[j + 3].substring(7, bombsV[j + 3].length() - 1)));
                    }
                    
                    playerC++;
                }
                
                x = 0;
                y = 0;
            }
            
            reader.close();
            
            //Output all players
//            System.out.println(context);
//            System.out.println("You :\n" + me.toString() + "\n\nTHEM:");
//            
//            for (int i = 0; i < players.length; i++)
//            {
//                System.out.println(players[i].toString());
//            }
//        
//            //Output all moves of all players
//            System.out.println(context);
//            System.out.println("You = " + me.getName() + ": " + Arrays.toString(getAvailPlayerActions(me, me.getXCoord(), me.getYCoord()).getAllOperations()));
//            
//            for (int i = 0; i < players.length; i++)
//            {
//                System.out.println(players[i].getName() + ": " + Arrays.toString(getAvailPlayerActions(players[i], players[i].getXCoord(), players[i].getYCoord()).getAllOperations()));
//            }
            
            thinkAhead();
        }
        catch (IOException ex)
        {
            Logger.getLogger(MiniMaxEnigine.class.getName()).log(Level.SEVERE, null, ex);
        }
    }
    
    /** THIS IS THE RECURSIVE *INITIATER FUNCTION*.
     *  First determine the options you will have to be choosing from
     *  Must determine if bomb blowing up and hitting you is a possibility before working out other enemy possibilities.
    */
    
    // TO ADD: POSITIVE POINTS FOR KILLING A PLAYER AND POSITIVE POINTS FOR HITTING DESTRUCTABLE WALL
    @SuppressWarnings("empty-statement")
    private void thinkAhead() throws NullPointerException
    {
        //IMPORTANT NOTE: THIS ALGORITHM WILL IGNORE POWER UPPS. CONTINGENCIES MIGHT HAVE TO BE MADE FOR THIS
        Player temp;        //for YOU = 'me' object
        Player restore;     //for opponents = 'player[i]'
        
        Bomb[] myBombs = null;
        Bomb[] theirBombs = null;
        
        int k;                  //k is the offset for player children nodes (see later implementation)
        int biggest = 0;        //for recursive func
        int smallest = 0;
        int ret = 0;
        //tempAccumilator = 0;
        
        String currAction;
        
        Action myAction;
        Action playersActions;
        MMNode currRoot = root;
        
        //Decrement all bomb times with 1
        me.redAllBombFuses();        
        
        //Work out YOUR avail actions      
        myAction = getAvailPlayerActions(me, me.getXCoord(), me.getYCoord());
        
        //Save YOUR actions and their rewards. This changes via recursive calls.
        yourAwards = new ActionAward(myAction);
        //System.out.println("All actions: " + yourAwards.toString());
        
        //Use constructor Player(char _name, int _x, int _y, int _rad, int _bombCounter)
        temp = new Player(me.getName(), me.getXCoord(), me.getYCoord(), me.getRad(), me.getBombNum());          //Save 'me' state
        
        //Set bomb temporaries
        if (me.getBombNum() > 0)
        {
            myBombs = new Bomb[me.getBombNum()];
            for (int i = 0; i < myBombs.length; i++)
            {
                //use bomb constructor Bomb(int _x, int _y, int _fuse, int _rad)
                myBombs[i] = new Bomb(me.getBombAt(i).getXCoord(), me.getBombAt(i).getYCoord(), me.getBombAt(i).getFuse(), me.getBombAt(i).getRad());
            }
        }
        
        for (int i = 0; i < myAction.getLength(); i++)
        {
            ret = 0;
            //change root node's childNum to YOUR number of actions
            currRoot.setChildrenLen(myAction.getLength());
            
            //Get award for action
            currAction = myAction.getOperationAt(i);
            //System.out.println("\n\n\n1 = " + me.toString() + "\nAction: " + currAction + "\n--------------------------------");
            
            //Save best action with biggest reward
            if (allAwards.getAwardForAction(currAction) > biggest)
            {
                biggest = allAwards.getAwardForAction(currAction);
            }
            
            //Change player state
            currRoot.setChildAt(i, currRoot.getLevel() + 1);     //Child type = YOUR Move
            me.changeState(currAction);
            
            currRoot = currRoot.getChildAt(i);
            
            //Now the next step will complete the two-part game state change: work out possible states of opponents (including bombs).
            //Children process. NOTE: in the child process, first reduce each bomb timer of each opponent player with 1 and then see if the bomb will explode and hit YOU
            
            //smallest = 0;
            //System.out.println("UPPER AA: " + currRoot.getLevel());
            if (currRoot.getLevel() + 1 <= root.getLevel() + maxLevel)       //setting 8 as max level
            {
                for (int j = 0; j < players.length && ret != Integer.MAX_VALUE; j++)
                {
                    //Check if bomb gets a destr wall
                    //and save best action with biggest reward
                    //and add pionts for each bomb that hits a player (opponent)
                    if (myBombs != null)
                    {
                        //use tempAccu as temp and k as accumilator
                        int tempAccu = 0;
                        k = 0;

                        //add pionts for each bomb that hits a destr wall
                        for (int l = 0; l < myBombs.length; l++)
                        {
                            tempAccu += myBombs[l].collectDesroyPoints();
                        }

                        tempAccu += allAwards.getAwardForAction(myAction.getOperationAt(i));
                        
                        //and add pionts for each bomb that hits a player (opponent) here
                        for (int l = 0; l < myBombs.length; l++)
                        {
                            if (me.checkBombVisionAt(l, players[j]))
                            {
                                k += 50;            //setting 50 as point for hitting player
                            }
                        }
                        
                        k += tempAccu;
                        
                        if (k > biggest)
                        {
                            biggest = k;
                        }
                        
                        k = 0;
                        tempAccu = 0;
                    }
                    
//                    if (myBombs != null)
//                    {
//                        for (int l = 0; l < myBombs.length; l++)
//                        {
//                            if (me.checkBombVisionAt(l, me))
//                            {
//                                //Remove bomb planted
//                                yourAwards.removeEntryWithAction(myAction.getOperationAt(i));
//                            }
//                        }
//                    }
                    
                    /* REMEMBER: One player can have >1 action
                     *           We also have to work out what the bombs of each player will do!!
                    */
                    
                    restore = new Player(players[j].getName(), players[j].getXCoord(), players[j].getYCoord(), players[j].getRad(), players[j].getBombNum());       //save current opponent's state
                    
                    //set temp opponent boms
                    if (players[j].getBombNum() > 0)
                    {
                        theirBombs = new Bomb[players[j].getBombNum()];
                    
                        for (int l = 0; l < theirBombs.length; l++)
                        {
                            //use bomb constructor Bomb(int _x, int _y, int _fuse, int _rad)
                            theirBombs[l] = new Bomb(players[j].getBombAt(l).getXCoord(), players[j].getBombAt(l).getYCoord(), players[j].getBombAt(l).getFuse(), players[j].getBombAt(l).getRad());
                        }
                    }
                    
                    //Check all bombs of opponent
                    for (int l = 0; l < players[j].getBombNum(); l++)
                    {
                        //System.out.print(players[j].getName() + " BombCheck:");
                        if (players[j].checkBombVisionAt(l, me))
                        {
                            //System.out.print(players[j].getName() + " BombCheck:");
                            
                            //Can't take this YOUR action
                            //System.out.print(" DIED 1.\n");
                            
                            //For NON-RECURSIVE FUNCTION:
                            //System.out.println("Remove: " + myAction.getOperationAt(i));
                            
                            
//                            if (!myAction.getOperationAt(i).equals("PB") && me.getBombNum() == 0)
//                            {
//                                yourAwards.removeEntryWithAction(myAction.getOperationAt(i));
//                            }
                            
                            //ORIGINAL:
                            if (!myAction.getOperationAt(i).equals("PB"))
                            {
                                yourAwards.removeEntryWithAction(myAction.getOperationAt(i));
                            }
                            
                            
                            //System.out.println("All actions: " + yourAwards.toString());
                            
                            //For recursive finction: return Integer.MAX_VALUE;
                        }
                        else
                        {
                            //System.out.print(" LIVED.\n");
                        }
                    }
                    
                    //Decrement all bomb times with 1 to simulate the game moving on one round
                    players[j].redAllBombFuses();
                    //System.out.println("j: " + players[j].toString());
                    
                    //get all actions of opponent
                    playersActions = getAvailPlayerActions(players[j], players[j].getXCoord(), players[j].getYCoord());
                    
                    //int k;
                    //for each player action alter player and then get reward
                    if (currRoot.getChildNum() == 0)
                    {
                        k = 0;
                        currRoot.setChildrenLen(playersActions.getLength());
                    }
                    else
                    {
                        k = currRoot.getChildNum();
                        currRoot.addChildrenLen(playersActions.getLength());
                    }
                    
                    //for each player action, alter player and get reward
                    for (int l = 0; l < playersActions.getLength() && ret != Integer.MAX_VALUE; l++)
                    {
                        //Get award for action
                        currAction = playersActions.getOperationAt(l);
                        //System.out.println("2 = " + players[j].toString() + "\nAction: " + currAction + "\n\n");

                        //Change player state
                        currRoot.setChildAt(l + k, currRoot.getLevel() + 1);     //Child type = THEIR Move
                        players[j].changeState(currAction);

                        //DO RECURSIVE CALL HERE
                        ret = EnginePistons(currRoot.getChildAt(l + k));
                        //FOLLOWS BELOW @AA
                        
                        //Dealocate MMNode
                        //currRoot.delCildrenOfNodeAt(l + k);
            
                        //Reset players to temp
                        players[j] = null;
                        players[j] = new Player(restore.getName(), restore.getXCoord(), restore.getYCoord(), restore.getRad(), restore.getBombNum());
                        
                        if (theirBombs != null)
                        {
                            for (int m = 0; m < players[j].getBombNum(); m++)
                            {
                                players[j].setBombAt(m, theirBombs[m].getXCoord(), theirBombs[m].getYCoord(), theirBombs[m].getFuse(), theirBombs[m].getRad());
                            }
                        }
                        
                        //@AA: Follow of Recursive call condition above:
                        if (ret == Integer.MAX_VALUE)
                        {
                            //No entry with right answer
                            //System.out.println("Yes Upper");
                            
                            //System.out.println("Remove: " + myAction.getOperationAt(i));
//                            if (!myAction.getOperationAt(i).equals("PB") && me.getBombNum() == 0)
//                            {
//                                yourAwards.removeEntryWithAction(myAction.getOperationAt(i));
//                            }
                            
                            //ORIGINAL
                            if (!myAction.getOperationAt(i).equals("PB"))
                            {
                                yourAwards.removeEntryWithAction(myAction.getOperationAt(i));
                            }
                            
                            
                            //System.out.println("New actions: " + yourAwards.toString());
                            
                            //break;
                            //break GOTOBREAK;
                        }
                        else
                        {
                            smallest += ret;
                            if (((allAwards.getAwardForAction(currAction) * (-1)) + smallest) < smallest)
                            {
                                smallest = allAwards.getAwardForAction(currAction) * (-1);
                            }
                        }
                    }
                }
            }
            
            //tempAccumilator += smallest;
            currRoot = root;
            
            //Dealocate MMNode
            //currRoot.delCildrenOfNodeAt(i);
            
            //reset me to original
            me = null;
            me = new Player(temp.getName(), temp.getXCoord(), temp.getYCoord(), temp.getRad(), temp.getBombNum());
            
            if (myBombs != null)
            {
                for (int m = 0; m < me.getBombNum(); m++)
                {
                    me.setBombAt(m, myBombs[m].getXCoord(), myBombs[m].getYCoord(), myBombs[m].getFuse(), myBombs[m].getRad());
                }
            }
            
            //ONLY IN INITIATER FUNCTION:
            if (yourAwards.hasAction(myAction.getOperationAt(i)))
            {
                yourAwards.setAwardForAction(myAction.getOperationAt(i), smallest + biggest);
            }
        }
        
        /* IN RECURSIVE FUNC:
         * return (smallest + biggest);
        */
        
        String winner = yourAwards.getTopAction();
        System.out.println("Best action: " + winner);
        
        int top = allAwards.getIndexOfAction(winner);   
        System.out.println("Best action number: " + top);
        
        if (top != -1)
        {
            //Set bestAction to top
            bestAction = top;
        }
        System.out.println("All actions: " + yourAwards.toString());
    }
    
    //EACH GO of the recursive call, set a temp variable before the you set the children array, then for each child change it's variable and go on.
    private int EnginePistons(MMNode _root) throws NullPointerException
    {
        //System.out.println("HERE");
        //Recursive caller function
        
        Player temp;        //for YOU = 'me' object
        Player restore;     //for opponents = 'player[i]'
        
        Bomb[] myBombs = null;
        Bomb[] theirBombs = null;
        
        int k;                  //k is the offset for player children nodes (see later implementation)
        int biggest = 0;        //for recursive func
        int smallest = 0;
        int ret = 0;
        //tempAccumilator = 0;
        
        String currAction;
        
        Action myAction;
        Action playersActions;
        MMNode currRoot = _root;
        
        //Decrement all bomb times with 1
        me.redAllBombFuses();
        //System.out.println("Me: " + me.toString());
        
        //Work out YOUR avail actions      
        myAction = getAvailPlayerActions(me, me.getXCoord(), me.getYCoord());
        
        //You need to return Integer.Max_Value if all player actions cause a YOU death. Thus, keep a flag array.
        boolean die = true;
        boolean[] dieForAll = new boolean[myAction.getLength()];
        
        //Use constructor Player(char _name, int _x, int _y, int _rad, int _bombCounter)
        temp = new Player(me.getName(), me.getXCoord(), me.getYCoord(), me.getRad(), me.getBombNum());          //Save 'me' state
        
        //Set bomb temporaries
        if (me.getBombNum() > 0)
        {
            myBombs = new Bomb[me.getBombNum()];
            for (int i = 0; i < myBombs.length; i++)
            {
                //use bomb constructor Bomb(int _x, int _y, int _fuse, int _rad)
                myBombs[i] = new Bomb(me.getBombAt(i).getXCoord(), me.getBombAt(i).getYCoord(), me.getBombAt(i).getFuse(), me.getBombAt(i).getRad());
            }
        }
        
        for (int i = 0; i < myAction.getLength(); i++)
        {
            ret = 0;
            //change root node's childNum to YOUR number of actions
            currRoot.setChildrenLen(myAction.getLength());
            
            //Get award for action
            currAction = myAction.getOperationAt(i);
            //System.out.println("1 = " + me.toString() + "\nAction: " + currAction);
            
            //Save best action with biggest reward
            if (allAwards.getAwardForAction(currAction) > biggest)
            {
                biggest = allAwards.getAwardForAction(currAction);
            }
            
            //Change player state
            currRoot.setChildAt(i, currRoot.getLevel() + 1);     //Child type = YOUR Move
            me.changeState(currAction);
            
            currRoot = currRoot.getChildAt(i);
            
            //Now the next step will complete the two-part game state change: work out possible states of opponents (including bombs).
            //Children process. NOTE: in the child process, first reduce each bomb timer of each opponent player with 1 and then see if the bomb will explode and hit YOU
            
            for (int j = 0; j < players.length && ret != Integer.MAX_VALUE; j++)
            {
                //Check if bomb gets a destr wall
                //and save best action with biggest reward
                //and add pionts for each bomb that hits a player (opponent)
                if (myBombs != null)
                {
                    //use tempAccu as temp and k as accumilator
                    int tempAccu = 0;
                    k = 0;

                    //add pionts for each bomb that hits a destr wall
                    for (int l = 0; l < myBombs.length; l++)
                    {
                        tempAccu += myBombs[l].collectDesroyPoints();
                    }

                    tempAccu += allAwards.getAwardForAction(myAction.getOperationAt(i));

                    //and add pionts for each bomb that hits a player (opponent) here
                    for (int l = 0; l < myBombs.length; l++)
                    {
                        if (me.checkBombVisionAt(l, players[j]))
                        {
                            k += 50;            //setting 50 as point for hitting player
                        }
                    }

                    k += tempAccu;

                    if (k > biggest)
                    {
                        biggest = k;
                    }

                    k = 0;
                    tempAccu = 0;
                }
                    
                if (myBombs != null)
                {
                    for (int l = 0; l < myBombs.length; l++)
                    {
                        if (me.checkBombVisionAt(l, me))
                        {
                            //Remove bomb planted
                            return Integer.MAX_VALUE;
                        }
                    }
                }


                /* REMEMBER: One player can have >1 action
                 *           We also have to work out what the bombs of each player will do!!
                */

                restore = new Player(players[j].getName(), players[j].getXCoord(), players[j].getYCoord(), players[j].getRad(), players[j].getBombNum());       //save current opponent's state

                //set temp opponent boms
                if (players[j].getBombNum() > 0)
                {
                    theirBombs = new Bomb[players[j].getBombNum()];

                    for (int l = 0; l < theirBombs.length; l++)
                    {
                        //use bomb constructor Bomb(int _x, int _y, int _fuse, int _rad)
                        theirBombs[l] = new Bomb(players[j].getBombAt(l).getXCoord(), players[j].getBombAt(l).getYCoord(), players[j].getBombAt(l).getFuse(), players[j].getBombAt(l).getRad());
                    }
                }

                //Check all bombs of opponent
                for (int l = 0; l < players[j].getBombNum(); l++)
                {
                    //IMPORTANT NOTE: THIS ALGORITHM WILL IGNORE POWER UPPS. CONTINGENCIES MIGHT HAVE TO BE MADE FOR THIS

                    if (players[j].checkBombVisionAt(l, me))
                    {
                        //System.out.println("\nME: " + me.toString());
                        //System.out.println(players[j].bombsToString());

                        //Can't take this YOUR action
                        //System.out.print(" DIED 2 for action: " + myAction.getOperationAt(i) +  ".\n");

                        //For recursive finction:
                        return Integer.MAX_VALUE;
                    }
                    else
                    {
                        //System.out.print(" LIVED.\n");
                    }
                }
                    
                    
                //System.out.println("AA: " + currRoot.getLevel());
                if (currRoot.getLevel() + 1 < root.getLevel() + maxLevel)       //setting 8 as max level
                {
                    //Decrement all bomb times with 1 to simulate the game moving on one round
                    players[j].redAllBombFuses();
                    //System.out.println("Player: " + players[j].toString());
                    
                    //get all actions of opponent
                    playersActions = getAvailPlayerActions(players[j], players[j].getXCoord(), players[j].getYCoord());
                    
                    //int k;
                    //for each player action alter player and then get reward
                    if (currRoot.getChildNum() == 0)
                    {
                        k = 0;
                        currRoot.setChildrenLen(playersActions.getLength());
                    }
                    else
                    {
                        k = currRoot.getChildNum();
                        currRoot.addChildrenLen(playersActions.getLength());
                    }
                    
                    for (int l = 0; l < playersActions.getLength(); l++)
                    {
                        //for each player action, alter player and get reward
                        //Get award for action
                        currAction = playersActions.getOperationAt(l);
                        //System.out.println("2 = " + players[j].toString() + "\nAction: " + currAction + "\n\n");

                        //Change player state
                        currRoot.setChildAt(l + k, currRoot.getLevel() + 1);     //Child type = THEIR Move
                        players[j].changeState(currAction);

                        //DO RECURSIVE CALL HERE
                        ret = EnginePistons(currRoot.getChildAt(l + k));
                        //FOLLOWS BELOW @AA
                        
                        //Dealocate MMNode
                        //currRoot.delCildrenOfNodeAt(l + k);
            
                        //Reset players to temp
                        players[j] = null;
                        players[j] = new Player(restore.getName(), restore.getXCoord(), restore.getYCoord(), restore.getRad(), restore.getBombNum());
                        
                        if (theirBombs != null)
                        {
                            for (int m = 0; m < players[j].getBombNum(); m++)
                            {
                                players[j].setBombAt(m, theirBombs[m].getXCoord(), theirBombs[m].getYCoord(), theirBombs[m].getFuse(), theirBombs[m].getRad());
                            }
                        }
                        
                        //@AA: Follow of Recursive call condition above:
                        if (ret == Integer.MAX_VALUE)
                        {
                            //System.out.println("Yes Lower for level: " + currRoot.getLevel());
                            break;
                            
//                            //tempAccumilator += smallest;
//                            currRoot = _root;
//
//                            //Dealocate MMNode
//                            //currRoot.delCildrenOfNodeAt(i);
//
//                            //reset me to original
//                            me = null;
//                            me = new Player(temp.getName(), temp.getXCoord(), temp.getYCoord(), temp.getRad(), temp.getBombNum());
//
//                            if (myBombs != null)
//                            {
//                                for (int m = 0; m < me.getBombNum(); m++)
//                                {
//                                    me.setBombAt(m, myBombs[m].getXCoord(), myBombs[m].getYCoord(), myBombs[m].getFuse(), myBombs[m].getRad());
//                                }
//                            }
//            
//                            break GOTOBREAK;
                        }
                        else
                        {
                            if (die)        //No return except Integer.Max_Value yet
                            {
                                die = false;        //There is at least one value that didn't return a death
                            }
                            
                            smallest += ret;
                            
                            if (((allAwards.getAwardForAction(currAction) * (-1)) + smallest) < smallest)
                            {
                                smallest = allAwards.getAwardForAction(currAction) * (-1);
                            }
                        }
                    }
                }
                else
                {
                    die = false;
                }
            }
            
            dieForAll[i] = die;
            
            //tempAccumilator += smallest;
            currRoot = _root;
            
            //Dealocate MMNode
            //currRoot.delCildrenOfNodeAt(i);
            
            //reset me to original
            me = null;
            me = new Player(temp.getName(), temp.getXCoord(), temp.getYCoord(), temp.getRad(), temp.getBombNum());
            
            if (myBombs != null)
            {
                for (int m = 0; m < me.getBombNum(); m++)
                {
                    me.setBombAt(m, myBombs[m].getXCoord(), myBombs[m].getYCoord(), myBombs[m].getFuse(), myBombs[m].getRad());
                }
            }
        }
        
        die = true;
        for (int i = 0; i < dieForAll.length; i++)
        {
            if (!dieForAll[i])          //There is at least one value that didn't return a death
            {
                die = false;
                break;
            }
        }
        
        if (die)            //All values of recursion returned a die
        {
            return Integer.MAX_VALUE;
        }
        
        return (smallest + biggest);
    }
    
    //thinkAhead help function: Works out actions based on position
    private Action getAvailPlayerActions(Player player, int newX, int newY)
    {
        char u = 0, d = 0, l = 0, r = 0;
        String[] tempMap;
        Action playerAction;
        
        //Convert context to array
        tempMap = context.split("\\n");
        
        //Goto pos(newX, newY) and imagine that the player is now here. Check what he can do by looking at map to the left, right, up and down of
        //the player pos (if the player himself is at any of these positions, ignore it and see the pos at empty). Check to see if these positions
        //are taken up by another player by calling their (getX - and YCoord functions.)
        
        //Check old player positions i.o.w check if player's old pos is in range of moveable
        if (player.getXCoord() == newX && player.getYCoord() == newY - 1)
        {
            //Is above player
            u = ' ';
        }
        else if (player.getXCoord() == newX && player.getYCoord() == newY + 1)
        {
            //Is below player
            d =  ' ';
        }
        else if (player.getXCoord() == newX - 1 && player.getYCoord() == newY)
        {
            //Is to the left of player
            l =  ' ';
        }
        else if (player.getXCoord() == newX + 1 && player.getYCoord() == newY)
        {
            //Is to the right of player
            r =  ' ';
        }
        
        //Check other player positions
        for (int i = 0; i < players.length + 1; i++)
        {
            if (i < players.length)
            {
                char currName = players[i].getName();
                if (u == 0 && players[i].getXCoord() == newX && players[i].getYCoord() == newY - 1)
                {
                    //Is above player
                    u = currName;
                }
                else if (d == 0 && players[i].getXCoord() == newX && players[i].getYCoord() == newY + 1)
                {
                    //Is below player
                    d = currName;
                }
                else if (l == 0 && players[i].getXCoord() == newX - 1 && players[i].getYCoord() == newY)
                {
                    //Is to the left of player
                    l = currName;
                }
                else if (r == 0 && players[i].getXCoord() == newX + 1 && players[i].getYCoord() == newY)
                {
                    //Is to the right of player
                    r = currName;
                }
            }
            else
            {
                char currName = me.getName();
                if (u == 0 && me.getXCoord() == newX && me.getYCoord() == newY - 1)
                {
                    //Is above player
                    u = currName;
                }
                else if (d == 0 && me.getXCoord() == newX && me.getYCoord() == newY + 1)
                {
                    //Is below player
                    d = currName;
                }
                else if (l == 0 && me.getXCoord() == newX - 1 && me.getYCoord() == newY)
                {
                    //Is to the left of player
                    l = currName;
                }
                else if (r == 0 && me.getXCoord() == newX + 1 && me.getYCoord() == newY)
                {
                    //Is to the right of player
                    r = currName;
                }
            }
        }
        
        if (u == 0)
        {
            u = tempMap[newY - 1].charAt(newX);
        }
        
        if (d == 0)
        {
            d = tempMap[newY + 1].charAt(newX);
        }
        
        if (l == 0)
        {
            l = tempMap[newY].charAt(newX - 1);
        }
        
        if (r == 0)
        {
            r = tempMap[newY].charAt(newX + 1);
        }
        
        //Actions for each player: U (Up), D (Down), L (Left), R (Right), PB (Plant Bomb), RBT (Reduce Bomb Time to 1), N (Nothing)
        //NO!! =>> I think we can ignore the RBT choice, since we're working on the worst case assumption of bomb detonation (3s)
        playerAction = new Action(new String[]{"N"});
        
        if (player.hasLiveBomb())
        {
            //Can't do this if you are in range of own bomb
            
            //Check if in range of own bomb
            if (player.getName() == me.getName())
            {
                if (!me.checkOwnBombVisionAt(me.getBombIndexWithSmallestFuse(), me))
                {
                    playerAction.addOperation("RBT");
                }
            }
            else
            {
                playerAction.addOperation("RBT");
            }
        }
        
        if (player.canPlaceBomb())
        {
            //check if can escape bomb if planted
            if (player.getName() == me.getName())
            {
                if (canEscapeOwnBomb(me, new Bomb(me.getXCoord(), me.getYCoord(), me.getRad())))
                {
                    playerAction.addOperation("PB");
                }
            }
            else
            {
                playerAction.addOperation("RB");
            }
        }
        
        if (u == ' ' || u == '!' || u == '&' || u == '$')
        {
            playerAction.addOperation("U");
        }
        
        if (d == ' ' || d == '!' || d == '&' || d == '$')
        {
            playerAction.addOperation("D");
        }
        
        if (l == ' ' || l == '!' || l == '&' || l == '$')
        {
            playerAction.addOperation("L");
        }
        
        if (r == ' ' || r == '!' || r == '&' || r == '$')
        {
            playerAction.addOperation("R");
        }
        
        return playerAction;
    }
    
    public int getBestAction()
    {
        return bestAction;
    }

    private boolean canEscapeOwnBomb(Player escapeE, Bomb bombIndex)
    {
        int fuse = bombIndex.getFuse();
        
        if (fuse >= 2)
        {
            //Get reduced map:
            int pX = escapeE.getXCoord();
            int pY = escapeE.getYCoord();
            int rad = bombIndex.getRad();
            int j = pY;      //temp accumilator

            //Have a for loop for every direction (l, r, u, d)

            //Check 'up'
            for (int i = 0; i < fuse; i++)
            {
                //Check 'up'
                j = pY;
                j -= 1;
                
                if (j >= 1)
                {
                    if (context.split("\\n")[j].charAt(pX) != '#' && context.split("\\n")[j].charAt(pX) != '+')
                    {
                        if (Math.abs(j - pY) > rad || canMoveLeftOrRight(pX, context.split("\\n")[j]))
                        {
                            return true;        //don't return yet
                        }
                    }
                    else
                    {
                        break;
                    }
                }
                else
                {
                    break;
                }
            }
            
            j = pY;
            //Check 'down'
            for (int i = 0; i < fuse; i++)
            {
                j += 1;
                
                if (j <= context.split("\\n").length - 1)
                {
                    if (context.split("\\n")[j].charAt(pX) != '#' && context.split("\\n")[j].charAt(pX) != '+')
                    {
                        if (Math.abs(j - pY) > rad || canMoveLeftOrRight(pX, context.split("\\n")[j]))
                        {
                            return true;        //don't return yet
                        }
                    }
                    else
                    {
                        break;
                    }
                }
                else
                {
                    break;
                }
            }
            
            j = pX;
            
            //Check 'left'
            for (int i = 0; i < fuse; i++)
            {
                j -= 1;
                
                if (j >= 1)
                {
                    if (context.split("\\n")[j].charAt(pX) != '#' && context.split("\\n")[j].charAt(pX) != '+')
                    {
                        if (Math.abs(j - pX) > rad || canMoveUpOrDown(j, pY))
                        {
                            return true;        //don't return yet
                        }
                    }
                    else
                    {
                        break;
                    }
                }
                else
                {
                    break;
                }
            }
            
            j = pX;
            
            //Check 'right'
            for (int i = 0; i < fuse; i++)
            {
                
                j += 1;
                
                if (j <= context.split("\\n")[0].length() - 1)
                {
                    if (context.split("\\n")[j].charAt(pX) != '#' && context.split("\\n")[j].charAt(pX) != '+')
                    {
                        if (Math.abs(j - pX) > rad || canMoveUpOrDown(j, pY))
                        {
                            return true;        //don't return yet
                        }
                    }
                    else
                    {
                        break;
                    }
                }
                else
                {
                    break;
                }
            }
        }
        
        return false;
    }

    private boolean canMoveLeftOrRight(int xCoord, String row)
    {
        if (xCoord > 1)
        {
            //Left
            if (row.charAt(xCoord - 1) == ' ' || row.charAt(xCoord - 1) == '!' || row.charAt(xCoord - 1) == '&' || row.charAt(xCoord - 1) == '$')
            {
                return true;
            }
        }
        
        if (xCoord < 20)
        {
            //Right
            if (row.charAt(xCoord + 1) == ' ' || row.charAt(xCoord + 1) == '!' || row.charAt(xCoord + 1) == '&' || row.charAt(xCoord + 1) == '$')
            {
                return true;
            }
        }
        
        return false;
    }

    private boolean canMoveUpOrDown(int xCoord, int yCoord)
    {
        String[] row = context.split("\\n");
        if (yCoord > 1)
        {
            if (row[yCoord - 1].charAt(xCoord) == ' ' || row[yCoord - 1].charAt(xCoord) == '!' || row[yCoord - 1].charAt(xCoord) == '&' || row[yCoord - 1].charAt(xCoord) == '$')
            {
                return true;
            }
        }
        
        if (yCoord < row.length - 2)
        {
            if (row[yCoord + 1].charAt(xCoord) == ' ' || row[yCoord + 1].charAt(xCoord) == '!' || row[yCoord + 1].charAt(xCoord) == '&' || row[yCoord + 1].charAt(xCoord) == '$')
            {
                return true;
            }
        }
        
        return false;
    }
    
    //@funciton Stores nodes of MiniMax tree
    private class MMNode
    {
        private int level;      //Reward is Your points = 'me' points
        private MMNode[] children;
        //private Player[] restore;       //THIS MIGHT NOT NEED TO BE HERE
        
        public MMNode(int _level)
        {
            level = _level;
            children = new MMNode[0];
        }
        
        public MMNode(int _level, int childNum)
        {
            level = _level;
            children = new MMNode[childNum];
        }
        
        public MMNode getChildAt(int index)
        {
            if (index >= 0 && index < children.length)
            {
                return children[index];
            }
            
            return null;
        }
        
        public int getChildNum()
        {
            return children.length;
        }
        
        public int getLevel()
        {
            return level;
        }
        
        public void setChildAt(int index, int _level)
        {
            if (index >= 0 && index < children.length)
            {
                children[index] = new MMNode(_level);
            }
        }
        
        public void delCildrenOfNodeAt(int index)
        {
            if (index >= 0 && index <= children.length)
            {
                children[index] = new MMNode(children[index].getLevel());
            }
        }
        
        public void setChildrenLen(int childNum)
        {
            children = new MMNode[childNum];
        }
        
        public void addChildrenLen(int childNum)
        {
            MMNode[] temp = new MMNode[children.length + childNum];
            System.arraycopy(children, 0, temp, 0, children.length);
            children = temp;
        }
        
        public void setLevel(int _level)
        {
            level = _level;
        }
    }
    
    //Used to set associative array: for {this} action, you get {this} award
    private class ActionAward
    {
        String[] actionType;
        int[] award;
        
        public ActionAward(Action actions)
        {
            actionType = actions.getAllOperations();
            award = new int[actionType.length];
            setRewardsFromAll();
        }
        
        public ActionAward(String[] _actionType, int[] _award)
        {
            actionType = _actionType;
            award = _award;
        }
        
        @Override
        public String toString()
        {
            String a = "";
            
            if (actionType != null)
            {
                for (int i = 0; i < actionType.length; i++)
                {
                    a += actionType[i] + " = " + award[i] + "; ";
                }
            }
            
            return a;
        }
        
        private void setRewardsFromAll()
        {
            for (int i = 0; i < actionType.length; i++)
            {
                award[i] = allAwards.getAwardForAction(actionType[i]);
            }
        }
        
        public void removeEntryWithAction(String _actionType)
        {
            //System.out.println("Action: " + _actionType);
            if (actionType != null)
            {
                for (int i = 0; i < actionType.length; i++)
                {
                    if (actionType[i].equals(_actionType))
                    {
                        actionType[i] = "";
                    }
                }

//                String[] tempS = new String[actionType.length - 1];
//                int[] tempI = new int[actionType.length - 1];
//                int bCount = 0;
//
//                for (int i = 0; i < actionType.length; i++)
//                {
//                    if (!actionType[i].equals(""))
//                    {
//                        tempS[bCount] = actionType[i];
//                        tempI[bCount] = award[i];
//                        bCount++;
//                    }
//                }
//
//                actionType = tempS;
//                award = tempI;
            }
            else
            {
                actionType = null;
                award = null;
            }
        }
        
        public int getAwardForAction(String _actionType)
        {
            if (actionType != null)
            {
                for (int i = 0; i < actionType.length; i++)
                {
                    if (actionType[i].equals(_actionType))
                    {
                        return award[i];
                    }
                }
            }
            
            return -1;
        }
        
        public int getIndexOfAction(String _actionType)
        {
            //System.out.println("All actions: " + this.toString() + "\ncurr: " + _actionType + "\n");
            if (actionType != null)
            {
                for (int i = 0; i < actionType.length; i++)
                {
                    if (actionType[i].equals(_actionType))
                    {
                        return i;
                    }
                }
            }
            
            return -1;
        }

        public void setAwardAt(int i, int _award)
        {
            if (actionType != null)
            {
                award[i] = _award;
            }
        }

        public void setAwardForAction(String _actionType, int _award)
        {
            if (actionType != null)
            {
                for (int i = 0; i < actionType.length; i++)
                {
                    if (actionType[i].equals(_actionType))
                    {
                        award[i] = _award;
                    }
                }
            }
        }

        public boolean hasAction(String _actionType)
        {
            if (actionType != null)
            {
                for (int i = 0; i < actionType.length; i++)
                {
                    if (actionType[i].equals(_actionType))
                    {
                        return true;
                    }
                }
            }
            
            return false;
        }

        private String getTopAction()
        {
            if (actionType != null && actionType.length > 0)
            {
                String[] actions = new String[actionType.length];
                int biggset = Integer.MIN_VALUE;
                int nums = 0;

                for (int i = 0; i < actionType.length; i++)
                {
                    //System.out.println("B: " + biggset + ", curr: " + award[i]);
                    if (!actionType[i].equals(""))
                    {
                        if (award[i] > biggset)
                        {
                            //Clear array and start from beginning
                            biggset = award[i];
                            actions = new String[actionType.length];
                            nums = 0;

                            actions[nums] = actionType[i];
                            nums++;
                        }
                        else if (award[i] == biggset)
                        {
                            actions[nums] = actionType[i];
                            nums++;
                        }
                    }
                }

                if (nums > 1)
                {
                    biggset = (int)(Math.random() * ((nums - 1) + 1));
                }
                else
                {
                    biggset = nums - 1;
                }

                return actions[biggset];
            }
            else
            {
                return "N";
            }
        }
    }
    
    //PLAYERS WILL BE GENERATED BY THE ENGINE FOR EACH NODE    
    private class Player
    {
        private char name;        //A, B, C, D
        
        //CAN make bomb[] a priority queue later?
        private Bomb[] bombs;        //Able to see 15 moves ahead with 3s min per bomb, gives 15 / 3 = 5 max bombs, but must also compensate for bombs already palced
        private int bombCounter = 0;
        private int bombBag = 1;
        
        //MIGHT NOT NEED TO HAVE "points" HERE, CHECK THIS
        private int x, y, rad;       //y = rows; x = col, thus in graph form: xER{0, +inf}, yER{0, -inf}
        
        public Player(char _name)
        {
            name = _name;
            rad = 1;
            bombs = new Bomb[bombBag];
        }
        
        public Player(char _name, int _x, int _y)
        {
            name = _name;
            x = _x;
            y = _y;
            rad = 1;
            bombs = new Bomb[bombBag];
        }
        
        public Player(char _name, int _x, int _y, int _rad)
        {
            name = _name;            
            x = _x;
            y = _y;
            rad = _rad;
            bombs = new Bomb[bombBag];
        }
        
        public Player(char _name, int _x, int _y, int _rad, int _bombCounter)
        {
            name = _name;
            bombCounter = _bombCounter;
            
            x = _x;
            y = _y;
            
            rad = _rad;
            bombs = new Bomb[bombBag];
        }
        
        public Player(char _name, int _x, int _y, int _rad, int _bombCounter, int _bombBag)
        {
            name = _name;
            bombCounter = _bombCounter;
            
            x = _x;
            y = _y;
            
            rad = _rad;
            bombBag = _bombBag;
            bombs = new Bomb[bombBag];
        }
        
        @Override
        public String toString()
        {
            String ret = "NAME: " + name + ", X: " + x + ", Y: " + y + ", RAD: " + rad + ", BOMBS: {";
            if (bombCounter > 0)
            {
                for (int i = 0; i < bombCounter; i++)
                {
                    ret += i + " = " + bombs[i].toString();
                    
                    if (i == bombCounter - 1)
                    {
                        ret += "}";
                    }
                    else
                    {
                        ret += "; ";
                    }
                }
            }
            else
            {
                ret += "null}";
            }
            
            return ret;
        }
        
        public int getXCoord()
        {
            return x;
        }
        
        public int getYCoord()
        {
            return y;
        }
        
        public char getName()
        {
            return name;
        }
        
        public int getRad()
        {
            return rad;
        }
        
        public void setXY(int _x, int _y)
        {
            x = _x;
            y = _y;
        }
        
        public Bomb getBombAt(int i)
        {
            if (bombs[i] != null)
            {
                return bombs[i];
            }
            
            return null;
        }
        
        public int getBombFuseAt(int i)
        {
            if (bombs[i] != null)
            {
                return bombs[i].getFuse();
            }
            
            return -1;
        }
        
        public int getBombRadAt(int i)
        {
            if (bombs[i] != null)
            {
                return bombs[i].getRad();
            }
            
            return -1;
        }
        
        public void setBombAt(int i, int _x, int _y, int _fuse, int _rad)
        {
            if (i < bombBag)
            {
                bombs[i] = new Bomb(_x, _y, _fuse, _rad);
            }
        }
        
        public int getBombNum()
        {
            return bombCounter;
        }
        
        //@return true: victim is in range AND fuse is 1
        //        false: otherwise
        public boolean checkBombVisionAt(int i, Player victim)
        {
            if (bombs[i] != null)
            {
                //System.out.println("Can see: " + bombs[i].canSee(victim) + ", fuse is 0: " + (bombs[i].getFuse() == 0));
                return (bombs[i].canSee(victim, true) && bombs[i].getFuse() == 0);
            }
            else
            {
                return false;
            }
        }
        
        //@return true: victim is in range AND fuse is 1
        //        false: otherwise
        public boolean checkOwnBombVisionAt(int i, Player victim)
        {
            if (bombs[i] != null)
            {
                return bombs[i].canSee(victim, false);
            }
            else
            {
                return false;
            }
        }
        
        public boolean hasLiveBomb()
        {
            return (bombCounter > 0);
        }
        
        public boolean hasBombAt(int bX, int bY)
        {
            for (int i = 0; i < bombCounter; i++)
            {
                if (bombs[i].getXCoord() == bX && bombs[i].getYCoord() == bY)
                {
                    return true;
                }
            }
            
            return false;
        }
        
        public boolean canPlaceBomb()
        {
            return (bombCounter < bombBag);
        }
        
        public void placeBomb()
        {
            if (canPlaceBomb())
            {
                bombs[bombCounter] = new Bomb(x, y, rad);
                bombCounter++;
            }
        }
        
        public void placeBomb(int _rad)
        {
            if (canPlaceBomb())
            {
                bombs[bombCounter] = new Bomb(x, y, _rad);
                bombCounter++;
            }
        }
        
        public void placeBomb(int _x, int _y, int _fuse, int _rad)
        {
            if (canPlaceBomb())
            {
                bombs[bombCounter] = new Bomb(_x, _y, _fuse, _rad);
                bombCounter++;
            }
        }
        
        public void redAllBombFuses()
        {
            if (bombCounter > 0)
            {
                for (int i = 0; i < bombCounter; i++)
                {
                    if (!bombs[i].decFuse())
                    {
                        bombs[i] = null;
                    }
                }

                Bomb[] tempB = new Bomb[bombBag];
                int bCount = 0;

                for (int i = 0; i < bombCounter; i++)
                {
                    if (bombs[i] != null)
                    {
                        tempB[bCount] = bombs[i];
                        bCount++;
                    }
                }

                bombs = tempB;
                bombCounter = bCount;
            }
        }

        public void changeState(String currAction)
        {
            //if (currAction.equals("N")) is implicit :: nothing has to change
            switch (currAction)
            {
                case "U":
                    y -= 1;
                    break;
                case "D":
                    y += 1;
                    break;
                case "L":
                    x -= 1;
                    break;
                case "R":
                    x += 1;
                    break;
                case "PB":
                    placeBomb();
                    break;
                case "RBT":
                    if (bombCounter > 0)
                    {
                        Bomb smallest = bombs[0];
                        
                        //System.out.println("COUNTER = " + bombCounter + "\n" + bombsToString());
                        
                        for (int i = 0; i < bombCounter; i++)
                        {
                            //System.out.println("I = " + i + ": " + bombs[i].toString());
                            if (bombs[i] != null && bombs[i].getFuse() < smallest.getFuse() )
                            {
                                smallest = bombs[i];
                            }
                        }
                        //redBombFuseAt(smallest);
                        smallest.redFuse();
                    }
                    break;
            }
        }
        
        public int getBombIndexWithSmallestFuse()
        {
            if (bombCounter > 0)
            {
                int sI = 0;
                Bomb smallest = bombs[0];

                //System.out.println("COUNTER = " + bombCounter + "\n" + bombsToString());

                for (int i = 0; i < bombCounter; i++)
                {
                    //System.out.println("I = " + i + ": " + bombs[i].toString());
                    if (bombs[i] != null && bombs[i].getFuse() < smallest.getFuse())
                    {
                        smallest = bombs[i];
                        sI = i;
                    }
                }
                
                return sI;
            }
            
            return -1;      //should not be possible
        }

        private String bombsToString()
        {
            String a = "";
            for (int i = 0; i < bombCounter; i++)
            {
                a += i + ": " + bombs[i].toString() + "; ";
            }
            return a;
        }
    }
    
    //Small bomb class for convenience
    //Regarding bombs:
    // * the min release time is 4s, so wait until level 2 (compensating for RBT move) and only then consider that a bomb might go off
    // * max bomb radius = 32
    private class Bomb
    {
        //Action = blow up. When blow up, give player who owns bomb 10 points (compensating for worst case: hits dextructable wall)
        private int x, y, fuse, rad;
        
        public Bomb(int _x, int _y)
        {
            x = _x;
            y = _y;
            fuse = 4;
            rad = context.split("\\n")[0].length() - 3;     //in 21x21 map: 18
        }
        
        public Bomb(int _x, int _y, int _rad)
        {
            x = _x;
            y = _y;
            fuse = 4;
            rad = _rad;
        }
        
        public Bomb(int _x, int _y, int _fuse, int _rad)
        {
            x = _x;
            y = _y;
            fuse = _fuse;
            rad = _rad;
        }
        
        @Override
        public String toString()
        {
            return "[x: " + x + ", y: " + y + ", fuse: " + fuse + ", rad: " + rad + "]";
        }
        
        public int getXCoord()
        {
            return x;
        }
        
        public int getYCoord()
        {
            return y;
        }
        
        public int getRad()
        {
            return rad;
        }
        
        public int getFuse()
        {
            return fuse;
        }
        
        public void redFuse()
        {
            fuse = 1;
        }
        
        //@return   true: bomb still relevant
        //          false: bomb not relevant anymore (fuse < 0)
        public boolean decFuse()
        {
            fuse -= 1;
            return (fuse >= 0);
        }
        
        /**
         * 
         * @param   victom player possibly in range
         * @param   verbose true if you want to consider fuse, false otherwise
         * 
         * @return  true: victim is in range
         *          false: victim is NOT in range
        */
        
        public boolean canSee(Player victom, boolean verbose)
        {
            //for now, assume any + is already destroyed
            if (verbose)
            {
                if (fuse >= 0)
                {
                    if (y == victom.getYCoord() && Math.abs(victom.getXCoord() - x) <= rad)       //same row
                    {
                        //check to see if there are # that will block
                        String row = context.split("\\n")[y];

                        if (x < victom.getXCoord())
                        {
                            //Start from bomb x pos
                            for (int i = x + 1; i < victom.getXCoord(); i++)
                            {
                                if (row.charAt(i) == '#')
                                {
                                    return false;
                                }
                            }

                            return true;
                        }
                        else
                        {
                            //Start from victom x pos
                            for (int i = victom.getXCoord() + 1; i < x; i++)
                            {
                                if (row.charAt(i) == '#')
                                {
                                    return false;
                                }
                            }

                            return true;
                        }
                    }
                    else if (x == victom.getXCoord() && Math.abs(victom.getYCoord() - y) <= rad)      //same col
                    {
                        //check to see if there are # that will block
                        String[] rows = context.split("\\n");

                        if (y < victom.getYCoord())
                        {
                            //Start from bomb y pos
                            for (int i = y + 1; i > victom.getYCoord(); i++)
                            {
                                if (rows[i].charAt(x) == '#')
                                {
                                    return false;
                                }
                            }

                            return true;
                        }
                        else
                        {
                            //Start from victim y pos
                            for (int i = victom.getYCoord() + 1; i > y; i++)
                            {
                                if (rows[i].charAt(x) == '#')
                                {
                                    return false;
                                }
                            }

                            return true;
                        }
                    }

                    return false;
                }
                else
                {
                    return false;
                }
            }
            else
            {
                if (y == victom.getYCoord() && Math.abs(victom.getXCoord() - x) <= rad)       //same row
                {
                    //check to see if there are # that will block
                    String row = context.split("\\n")[y];

                    if (x < victom.getXCoord())
                    {
                        //Start from bomb x pos
                        for (int i = x + 1; i < victom.getXCoord(); i++)
                        {
                            if (row.charAt(i) == '#')
                            {
                                return false;
                            }
                        }

                        return true;
                    }
                    else
                    {
                        //Start from victom x pos
                        for (int i = victom.getXCoord() + 1; i < x; i++)
                        {
                            if (row.charAt(i) == '#')
                            {
                                return false;
                            }
                        }

                        return true;
                    }
                }
                else if (x == victom.getXCoord() && Math.abs(victom.getYCoord() - y) <= rad)      //same col
                {
                    //check to see if there are # that will block
                    String[] rows = context.split("\\n");

                    if (y < victom.getYCoord())
                    {
                        //Start from bomb y pos
                        for (int i = y + 1; i > victom.getYCoord(); i++)
                        {
                            if (rows[i].charAt(x) == '#')
                            {
                                return false;
                            }
                        }

                        return true;
                    }
                    else
                    {
                        //Start from victim y pos
                        for (int i = victom.getYCoord() + 1; i > y; i++)
                        {
                            if (rows[i].charAt(x) == '#')
                            {
                                return false;
                            }
                        }

                        return true;
                    }
                }

                return false;
            }
        }
        
        //@return points for all destroyed walls
        public int collectDesroyPoints()
        {
            if (fuse == 0)
            {
                int points = 0;
                String[] rows = context.split("\\n");

                //get points in row of bomb
                for (int i = x + 1; i < (x + rad) && i < 21; i++)
                {
                    if (rows[y].charAt(i) == '+')
                    {
                        points += 10;
                        break;
                    }
                }
                
                for (int i = x - 1; i > (x - rad) && i > 0; i--)
                {
                    if (rows[y].charAt(i) == '+')
                    {
                        points += 10;
                        break;
                    }
                }
                
                //get points in col of bomb
                for (int i = y + 1; i < (y + rad) && i < 21; i++)
                {
                    if (rows[i].charAt(x) == '+')
                    {
                        points += 10;
                        break;
                    }
                }
                
                for (int i = y - 1; i > (y - rad) && i > 0; i--)
                {
                    if (rows[i].charAt(x) == '+')
                    {
                        points += 10;
                        break;
                    }
                }
                
                return points;
            }
            else
            {
                return 0;
            }
        }
    }
}