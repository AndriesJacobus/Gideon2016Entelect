package bombbot;

//Problem: all choices are bad choices

public class InformedDesicion
{
    private String bestChoice;
    private String[] exclude = null;
    private int numNonRepeaters;
    private ContextList currentRef = null;

    public InformedDesicion(ContextList _currentRef)
    {
        bestChoice = "";
        numNonRepeaters = 0;
        currentRef = _currentRef;
    }

    public void setCurrentRef(ContextList _currentRef)
    {
        currentRef = _currentRef;
    }

    public void consider(String[][] _customContextList)
    {
        if (exclude == null && _customContextList != null)		//First setting
        {
            //_customContextList[i][0] = choice; _customContextList[i][1] = award (left, mid, right)

            numNonRepeaters = 0;
            exclude = new String[_customContextList.length];

            for (int i = 0; i < _customContextList.length; i++)
            {
                if (_customContextList[i][1].equals("RIGHT"))		//Finds first good value, might want to change later to consider all good values
                {
                    bestChoice = _customContextList[i][0];
                    break;      //Stops @ 1st
                }
                else
                {
                    boolean found = false;
                    for (int j = 0; j < exclude.length; j++)
                    {
                        if (_customContextList[i][0].equals(exclude[j]))
                        {
                            found = true;           //Is altready logged
                            break;
                        }
                    }

                    if (!found)         //No duplicates
                    {
                        //Insert into non repater choices (exclude)
                        exclude[numNonRepeaters] = _customContextList[i][0];
                        numNonRepeaters++;
                    }
                }
            }

            if (bestChoice.equals(""))
            {
                //No "good" decision, but there are a list of bad ones not to repeat
                bestChoice = currentRef.getRondomChoiceExcluding(exclude);
            }
        }
        else if (exclude != null)
        {
            //_customContextList[i][0] = choice; _customContextList[i][1] = award (left, mid, right)

            String[] temp = new String[numNonRepeaters + _customContextList.length];
            int counter = 0;

            for (int k = 0; k < numNonRepeaters; k++)		//Add all exclude's current vals
            {
                temp[counter] = exclude[k];
                counter++;
            }

            for (int i = 0; i < _customContextList.length; i++)
            {
                if (_customContextList[i][1].equals("RIGHT"))		//Finds first good value, might want to change later to consider all good values
                {
                    bestChoice = _customContextList[i][0];
                    break;		//Stops @ 1st
                }
                else
                {
                    boolean found = false;
                    for (int j = 0; j < temp.length; j++)
                    {
                        if (_customContextList[i][0].equals(temp[j]))
                        {
                            found = true;		//Is altready logged
                            break;
                        }
                    }

                    if (!found)		//No duplicates
                    {
                        //Insert into non repater choices (temp)
                        temp[counter] = _customContextList[i][0];
                        counter++;
                    }
                }
            }

            //exclude = null;
            exclude = temp;

            if (bestChoice.equals(""))
            {
                //No "good" decision, but there are a list of bad ones not to repeat
                bestChoice = currentRef.getRondomChoiceExcluding(exclude);
            }
        }
        else if (_customContextList == null)
        {
            //First time context is appearing, guess
            bestChoice = currentRef.getRondomChoice(currentRef.getActions());
        }
    }

    public String getDecision()
    {
        return bestChoice;
    }
}