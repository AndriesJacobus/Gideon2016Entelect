package bombbot;

/**
 * @author Jaco
 */

public class CLNode
{
    //Screen in input, reward is award, Action is choices available

    public String[][] context = null;
    public int reward = 0;
    public String choice = "";
    public boolean hasBack = false;
    public Register left = null;		//-
    public Register mid = null;                 //Same
    public Register right = null;		//+

    public CLNode(String[][] _context, int _var, String _action)
    {
        context = _context;
        reward = _var;
        choice = _action;
    }

    @Override
    public String toString()
    {
        String out = reward + ", Choice: " + choice + ", HasBack: " + (hasBack) + ", Left: " + (left != null) + ", Mid: " + (mid != null) + ", Right: " + (right != null) + ",\nContext: " + contextToString();
        if (!contextToString().equals("NULL"))
        {
            out += ",\n";
        }
        return out;
    }
    
    public boolean equals(CLNode two)
    {
        return (this.contextToString().equals(two.contextToString()) && this.reward == two.reward && this.choice.equals(two.choice));
    }

    public String toStringMin()
    {
        String out = reward + ",Choice:" + choice + ",";
        if (left != null)
        {
            out += "Left:true";
        } else if (mid != null)
        {
            out += "Mid:true";
        } else if (right != null)
        {
            out += "Right:true";
        } else
        {
            out += "HasBack:false";
        }

        out += ",Context:" + contextToString();
        if (!contextToString().equals("NULL"))
        {
            out += ",";
        }
        return out;
    }

    public String contextToString()
    {
        String out = "";

        for (int i = 0; i < context.length; i++)
        {
            for (int j = 0; j < context[i].length; j++)
            {
                out += context[i][j];
                if (j < context[i].length - 2)
                {
                    out += " ";
                }
            }

            if (i + 1 != context.length)
            {
                out += "";
            }
        }

        return out;
    }
}
