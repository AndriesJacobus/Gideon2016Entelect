package bombbot;

import java.util.Arrays;

public class ContextList
{
    protected Register begin;
    protected CLNode root;
    protected CLNode insertNode;
    protected Register insertNodeRegister;
    
    private Action choices;
    private int initial;
    private int numRegisters;
    
    public ContextList()
    {
        numRegisters = 0;
    }

    public ContextList(String[][] _context, int _var, Action _actions, String _choice)
    {
        initial = _var;
        choices = _actions;

        String temp = _choice;
        if (temp.equals("") || temp == null)
        {
            temp = getRondomChoice(choices);
        }
        
        begin = new Register(_context, _var, temp);
        root = begin.getHead();
        
        insertNode = root;
        insertNodeRegister = begin;
        numRegisters++;
    }

    //@param verbose: true for full desc, false for short desc
    public String toString(boolean verbose)
    {
        String out = "";
        
        if (root == null)
        {
            return "Error: ContextList is empty";
        }
        else
        {
            CLNode temp = root;
            
            //IMPLEMENT by iterating each child
            
            return out;
        }
    }
    
    public boolean equals(ContextList to)
    {
        //A CL tree is equal to another when they have the same contexts in the same order
        if (to.length() != this.length())
        {
            return false;
        }
        else
        {
            boolean foundOne = false;
            for (int i = 0; i < to.length(); i++)
            {
                if (!Arrays.deepEquals(to.getContexAt(i), this.getContexAt(i)))
                {
                    //Hass diff context at i
                    foundOne = true;
                    break;
                }
            }
            
            if(foundOne)
            {
                return false;
            }
            else
            {
                return true;
            }
        }
    }

    public void insertNode(String where, String[][] _context, int _var, String _choice)
    {
        //CHOICE MUST BE SET FROM RANDOM (getRondomChoice(choices))TO DEFINED HERE
        if (_context != null)
        {
            String choice = _choice;
            
            if (choice.equals(""))
            {
                choice = getRondomChoice(choices);
            }
            
            CLNode temp = new CLNode(_context, _var, choice);
            
            if (_context[0][0].equals("CODEENDOFALL"))          //Last node, no choice
            {
                temp = new CLNode(new String[][]{{"NULL", ""}}, _var, "NULL");
            }

            if (where.toUpperCase().equals("RIGHT"))
            {
                if (insertNode.right == null)
                {
                    insertNode.right = new Register(temp);
                }
                else
                {
                    //Check if node exists in Register
                    if (!insertNode.right.nodeIsPresent(temp))
                    {
                        insertNode.right.insertRegisterNode(_context, _var, choice);
                    }
                }

                insertNode.right.setIndex(insertNodeRegister.getIndex() + 1);
                insertNode.hasBack = true;
                                
                insertNodeRegister = insertNode.right;
                insertNode = temp;
                numRegisters++;
            }
            else if (where.toUpperCase().equals("MID"))
            {
                if (insertNode.mid == null)
                {
                    insertNode.mid = new Register(temp);
                }
                else
                {
                    //Check if node exists in Register
                    if (!insertNode.mid.nodeIsPresent(temp))
                    {
                        insertNode.mid.insertRegisterNode(_context, _var, choice);
                    }
                }

                insertNode.mid.setIndex(insertNodeRegister.getIndex() + 1);
                insertNode.hasBack = true;
                                
                insertNodeRegister = insertNode.mid;
                insertNode = temp;
                numRegisters++;
            }
            else if (where.toUpperCase().equals("LEFT"))
            {
                if (insertNode.left == null)
                {
                    insertNode.left = new Register(temp);
                }
                else
                {
                    //Check if node exists in Register
                    if (!insertNode.left.nodeIsPresent(temp))
                    {
                        insertNode.left.insertRegisterNode(_context, _var, choice);
                    }
                }

                insertNode.left.setIndex(insertNodeRegister.getIndex() + 1);
                insertNode.hasBack = true;
                                
                insertNodeRegister = insertNode.left;
                insertNode = temp;
                numRegisters++;
            }
            else
            {
                System.out.println("Error: Incorrect node position specified.");
            }
        }
    }

    public String getChoiceAt(int index)
    {
        if (index == 0)
        {
            //Root's choice
            return root.choice;
        }
        else if (index > numRegisters)
        {
            return "Error: Element at " + index + " does not exist!";
        }
        else
        {
            return null;
        }
    }
    
    public String[][] getContexAt(int index)
    {
        if (index == 0)
        {
            //Root's choice
            return root.context;
        }
        else if (index > numRegisters)
        {
            return new String[][]{{"Error: Element at " + index + " does not exist!", ""}};
        }
        else
        {
            return null;
        }
    }
    
    //Gets first right answer (fist node in register)
    public String getFirstChoiceWithContext(String[][] _context)
    {
        //Driver:
        return getFirstChoiceWithContextDriver(begin, _context);
    }
        
    private String getFirstChoiceWithContextDriver(Register beg, String[][] _context)
    {
        if (Arrays.deepEquals(_context, (new String[][]{{"", ""}})) || _context == null)
        {
            return "Error: Invalid context!";            
        }
        else
        {
            CLNode[] regElem = beg.getAllNodes();
                
            for (int j = 0; j < regElem.length; j++)
            {
                if (Arrays.deepEquals(regElem[j].context, _context))
                {
                    if (regElem[j].right != null)
                    {
                        //Right answer
                        return regElem[j].choice;
                    }
                }
                else
                {
                    String temp;
                    if (regElem[j].right != null)
                    {
                        temp = getFirstChoiceWithContextDriver(regElem[j].right, _context);

                        if (!temp.equals("Error: Could not find correct decision!"))
                        {
                            return temp;
                        }
                    }

                    if (regElem[j].mid != null)
                    {
                        temp = getFirstChoiceWithContextDriver(regElem[j].mid, _context);

                        if (!temp.equals("Error: Could not find correct decision!"))
                        {
                            return temp;
                        }
                    }

                    if (regElem[j].left != null)
                    {
                        temp = getFirstChoiceWithContextDriver(regElem[j].left, _context);

                        if (!temp.equals("Error: Could not find correct decision!"))
                        {
                            return temp;
                        }
                    }
                }
            }
            
            return "Error: Could not find correct decision!";
        }
    }

    public String[][] getChoicesWithContext(String[][] _context)
    {
        //Driver call:
        return getChoicesWithContextDriver(begin, _context);
    }
    
    public String[][] getChoicesWithContextDriver(Register beg, String[][] _context)
    {
        //Returns first choice with said context
        int howMany = getNumContexts(_context);
        
        if (howMany == 0)
        {
            return (new String[][]{{"", ""}});
        }
        else
        {
            //There are elements with given context (howMany > 0)
            String[][] all = new String[howMany][2];
            int currIndex = 0;
            CLNode[] regElem = beg.getAllNodes();
                
            for (int j = 0; j < regElem.length; j++)
            {
                if (Arrays.deepEquals(regElem[j].context, _context))
                {
                    all[currIndex][0] = regElem[j].choice;

                    if (regElem[j].right != null)
                    {
                        all[currIndex][1] = "RIGHT";
                    }
                    else if (regElem[j].mid != null)
                    {
                        all[currIndex][1] = "MID";
                    }
                    else if (regElem[j].left != null)
                    {
                        all[currIndex][1] = "LEFT";
                    }
                    else
                    {
                        all[currIndex][1] = "NULL";
                    }

                    currIndex++;
                }

                if (regElem[j].right != null)
                {
                    String[][] add = getChoicesWithContextDriver(regElem[j].right, _context);
                    for (int k = 0; k < add.length; k++)
                    {
                        all[currIndex] = add[k];
                        currIndex++;
                    }

                    //temp = regElem[i].right;
                }

                if (regElem[j].mid != null)
                {
                    String[][] add = getChoicesWithContextDriver(regElem[j].mid, _context);
                    for (int k = 0; k < add.length; k++)
                    {
                        all[currIndex] = add[k];
                        currIndex++;
                    }
                }

                if (regElem[j].left != null)
                {
                    String[][] add = getChoicesWithContextDriver(regElem[j].left, _context);
                    for (int k = 0; k < add.length; k++)
                    {
                        all[currIndex] = add[k];
                        currIndex++;
                    }
                }
            }

            return all;
        }
    }

    public int getNumContexts(String[][] _context)
    {
        //Driver:
        return getNumContextsDriver(begin, _context);
    }
    
    public int getNumContextsDriver(Register beg, String[][] _context)
    {
        if (!root.hasBack && Arrays.deepEquals(root.context, _context))
        {
            return 1;
        }
        else
        {
            int how = 0;
            CLNode[] regElem = beg.getAllNodes();
                
            for (int j = 0; j < regElem.length; j++)
            {
                if (Arrays.deepEquals(regElem[j].context, _context))
                {
                    how++;
                }

                if (regElem[j].right != null)
                {
                    how += getNumContextsDriver(regElem[j].right, _context);
                }

                if (regElem[j].mid != null)
                {
                    how += getNumContextsDriver(regElem[j].mid, _context);
                }

                if (regElem[j].left != null)
                {
                    how += getNumContextsDriver(regElem[j].left, _context);
                }
            }

            return how;
        }
    }

    public int getVarInsert()
    {
        return insertNode.reward;
    }
    
//    public String getStringAt(int index)
//    {
//        //Driver:
//        return getStringAtDriver(begin, index);
//    }
//    
//    public String getStringAtDriver(Register beg, int index)
//    {
//        if (index == 0)
//        {
//            //Root's choice
//            return root.toString();
//        }
//        else if (index > numRegisters)
//        {
//            return "Error: Element at " + index + " does not exist!";
//        }
//        else
//        {
//            CLNode temp = root;
//
//            for (int i = 0; i < index; i++)
//            {
//                if (temp.left != null)
//                {
//                    temp = temp.left;
//                }
//                else if (temp.mid != null)
//                {
//                    temp = temp.mid;
//                }
//                else
//                {
//                    temp = temp.right;
//                }
//            }
//
//            if (temp == null)
//            {
//                return "Error: Element at " + index + " does not exist!";
//            }
//            else
//            {
//                return temp.toString();
//            }
//        }
//    }

    public Action getActions()
    {
        return choices;
    }
    
    public String getRondomChoice(Action _choices)
    {
        int r = (int) (Math.random() * (_choices.getLength()));
        return _choices.getOperationAt(r);
    }

    public String getRondomChoiceExcluding(String[] exclude)
    {
        int hl = 0;
        for (int i = 0; i < choices.getLength(); i++)
        {
            for (int j = 0; j < exclude.length; j++)
            {
                if (!choices.getOperationAt(i).equals(exclude[j]))
                {
                    hl++;
                }
            }
        }

        String[] all = new String[hl];
        int t = 0;
        for (int i = 0; i < choices.getLength(); i++)
        {
            for (int j = 0; j < exclude.length; j++)
            {
                if (!choices.getOperationAt(i).equals(exclude[j]))
                {
                    all[t] = choices.getOperationAt(i);
                    t++;
                }
            }
        }

        Action temp = new Action(all);
        int r = (int) (Math.random() * (all.length));

        return temp.getOperationAt(r);
    }

    public String[] getAllChoices()
    {
        return choices.getAllOperations();
    }

    public int getFinalMark()
    {
        return insertNode.reward;
    }
    
    public int length()
    {
        return numRegisters;
    }
}