package bombbot;

/**
 * @author Jaco
 */

public class FreqScores
{
    
}
