package bombbot;

import java.util.Scanner;
import java.io.*;

public class BomberLearner
{
    //With the iris dataset, we have the answers, so there won't ever be a mid node initialized in the ContextList tree(s). When we move on to
    //datasets where the "answer" (i.e the choice giving the maximum pleasure) is not known, there will be a lot of mid values. The goal of the
    //A.I is then not only to maximize the positive reward variable, but also to minimize the amount of mid choices- don't play it safe!

    protected String[] temp = null;
    protected Action actions = null;
    protected int var = 0;
    protected String[][] screen = null;
    protected String[] answers = null;
    protected ContextList[] BomberRecall = null;
    protected int loop;
    protected int fullMarks;
    private double finalMark = -1.00;
    private int learningLoop = 0;

    public BomberLearner()
    {
        temp = new String[]{"Iris-setosa", "Iris-versicolor", "Iris-virginica"};
        actions = new Action(temp);
        var = new Integer(0);
        loop = 0;
        fullMarks = 150;
        learningLoop = fullMarks + 1;
    }

    public boolean splitData()
    {
        try
        {
            //Splitting the data
            Scanner scFile = new Scanner(new File("IrisDataset.txt"));
            screen = new String[151][1];
            answers = new String[151];

            for (int j = 0; scFile.hasNextLine(); j++)
            {
                screen[j][0] = "";
                String temp2 = scFile.nextLine();

                Scanner scLine = new Scanner(temp2).useDelimiter(",");

                for (int k = 0; scLine.hasNext(); k++)
                {
                    if (k < 4)
                    {
                        screen[j][0] += scLine.next();
                    }
                    if (k == 4)
                    {
                        answers[j] = scLine.next();
                    }
                }
                scLine.close();
            }

            scFile.close();

            return true;
        }
        catch (Exception e)
        {
            System.out.println("Error with scanner: " + e.toString());
            return false;
        }
    }

    public boolean train()
    {
        //Screen in input, var is award, Action is choices available
        //Test case for irises: goal is to guess what iris given what values.
        //Iris values: sepal length, sepal width, petal length, petal width, class (Iris Setosa, Iris Versicolour, Iris Virginica)
        
        try
        {
            //int loop = Integer.parseInt(JOptionPane.showInputDialog(null, "How many central interations do you want to perform?\n"));		//Test once for now
            loop = 25;
            BomberRecall = new ContextList[loop];

            //learning loop:
            System.out.println("Now Learning.\n");
            
            //EDIT SO THAT "index" VARIABLE REFERS TO A REGISTER AND THUS THAT THE CLNodes OF THAT REGISTER IS ALSO CONSIDERED
            
            for (int i = 0; i < loop; i++)
            {
                if (i == 0)
                {
                    //It[0], so don't recall past events
                    //System.out.println("Training initial set.");

                    BomberRecall[i] = new ContextList(new String[][]{{screen[0][0], ""}}, var, actions, "");

                    for (int j = 1; j < 151; j++)       //150 is hardcoded from IrisDataset.txt's linecount
                    {
                        //System.out.println("Choice is: '" + BomberRecall[i].getChoiceAt(j - 1) + "' while answer is '" + answers[j - 1] + "'");

                        if (j + 1 == 151)
                        {
                            //Last one should have no choice!
                            if (BomberRecall[i].getChoiceAt(j - 1).equals(answers[j - 1]))
                            {
                                BomberRecall[i].insertNode("right", new String[][]{{"CODEENDOFALL", ""}}, (BomberRecall[i].getVarInsert() + 1), "");
                            }
                            else
                            {
                                BomberRecall[i].insertNode("left", new String[][]{{"CODEENDOFALL", ""}}, (BomberRecall[i].getVarInsert() - 1), "");
                            }
                        }
                        else
                        {
                            if (BomberRecall[i].getChoiceAt(j - 1).equals(answers[j - 1]))
                            {
                                BomberRecall[i].insertNode("right", new String[][]{{screen[j][0], ""}}, (BomberRecall[i].getVarInsert() + 1), "");
                            }
                            else
                            {
                                BomberRecall[i].insertNode("left", new String[][]{{screen[j][0], ""}}, (BomberRecall[i].getVarInsert() - 1), "");
                            }
                        }
                    }
                }
                else
                {
                    //Recall past iterations also

                    for (int j = 0; j < 151; j++)
                    {
                        //Must still insert all nodes for BomberRecall[i]
                        InformedDesicion whim = new InformedDesicion(null);

                        if (j == 0)
                        {
                            //Create root
                            //whim = null;
                            whim = new InformedDesicion(null);
                                
                            var = 0;
                            for (int k = 0; k < i; k++)     //i is num LearningIterations, k is thus the BomberRecall index to backtrack
                            {
                                whim.setCurrentRef(BomberRecall[k]);
                                whim.consider(BomberRecall[k].getChoicesWithContext(new String[][]{{screen[j][0], ""}}));
                            }

                            BomberRecall[i] = new ContextList(new String[][]{{screen[0][0], ""}}, var, actions, whim.getDecision());
                        }
                        else
                        {
                            if (j + 1 == 151)
                            {
                                if (BomberRecall[i].getChoiceAt(j - 1).equals(answers[j - 1]))
                                {
                                    BomberRecall[i].insertNode("right", new String[][]{{"CODEENDOFALL", ""}}, (BomberRecall[i].getVarInsert() + 1), "");
                                }
                                else
                                {
                                    BomberRecall[i].insertNode("left", new String[][]{{"CODEENDOFALL", ""}}, (BomberRecall[i].getVarInsert() - 1), "");
                                }
                            }
                            else
                            {
                                //whim = null;
                                whim = new InformedDesicion(null);
                                for (int k = 0; k < i; k++) //i is num irisRecalls, k is thus the BomberRecall index to backtrack
                                {
                                    whim.setCurrentRef(BomberRecall[k]);
                                    whim.consider(BomberRecall[k].getChoicesWithContext(new String[][]{{screen[j][0], ""}}));
                                }

                                if (BomberRecall[i].getChoiceAt(j - 1).equals(answers[j - 1]))
                                {
                                    BomberRecall[i].insertNode("right", new String[][]{{screen[j][0], ""}}, (BomberRecall[i].getVarInsert() + 1), whim.getDecision());
                                }
                                else
                                {
                                    BomberRecall[i].insertNode("left", new String[][]{{screen[j][0], ""}}, (BomberRecall[i].getVarInsert() - 1), whim.getDecision());
                                }
                            }
                        }
                    }

                    //System.out.println("Done training set " + (i + 1) + ".");
                }

                if ((BomberRecall[i].toString(true).substring(0, 5)).equals("Error"))
                {
                    return false;
                }
                else
                {
                    //System.out.println("Final mark: " + BomberRecall[i].getFinalMark());

                    if (BomberRecall[i].getFinalMark() == fullMarks)
                    {
                        //Done, we won!
                        System.out.println("Training loop set for " + loop + " iterations, but was completed in " + (i + 1) + " iterations!");
                        loop = i + 1;
                        finalMark = 150.00;
                        break;
                    }
                    else
                    {
                        finalMark = (double) (BomberRecall[i].getFinalMark());
                    }
                }
            }

            return true;
        }
        catch (NumberFormatException e)
        {
            System.out.println("You entered the wrong data type. Please try again. (Original error: '" + e.toString() + "')");
            return false;
        }
    }

    public void printMemory()
    {
        if (BomberRecall == null)
        {
            System.out.println("The training membrane is empty.");
        }
        else
        {
            System.out.println("Now printing the memory for the IrisLearner:\n");
            for (int i = 0; i < loop; i++)
            {
                System.out.println("Displaying membrane " + i + ": \n");
                System.out.println(BomberRecall[i].toString(true));
                System.out.println("\n");
            }
        }
    }
    
    // CHANGE: BEST ENTRIES SHOULD BE AT FIRST POSITIONS
    public String recall(String[][] _context)
    {
        for (int i = loop; i > 0; i--)
        {
            //Back propagation, best entries are at last BomberRecall position
            String got = BomberRecall[i - 1].getFirstChoiceWithContext(_context);
            
            if(got.equals("Error: Invalid context!"))
            {
                System.out.println(got);
                return got;
            }
            else if (!got.equals("Error: Could not find correct decision!"))
            {
                return got;
            }
        }
        
        return "Error: Could not find correct decision!";
    }
    
    public String removeCommas(String removeE)
    {
        Scanner scRemove = new Scanner(removeE).useDelimiter(",");
        String removed = "";
        
        while (scRemove.hasNextLine())
        {            
            removed += scRemove.next();
        }
        
        return removed;
    }
    
    //Create function to create a cummilitive tree combined from
    //CLs with same contexts in the same order (equal) that either
    //has left node OR has both right and mid nodes.
    //                         MAYBE ALSO ADD:
    //B*-tree (OR tree with arrays for nodes?): 
    //right val with all right vals for specific context;
    //mid val with all mid vals for specific context;
    //(left val if there are more than one for specific context) 
    
    public void refine()
    {
        //Remove "junk" trees: Trees that have the same context for all nodes, but one or more nodes with hier preference
        //(hier preference = hier score)
        
        if (BomberRecall != null && loop != 0)
        {
            ContextList comparE, comparR;
            boolean repeat = false;

            do
            {
                repeat = false;
                for (int i = loop - 1; i > -1 && !repeat; i--)
                {
                    //Begin at end: most accurite tree
                    comparE = BomberRecall[i];

                    for (int j = 0; j < loop && !repeat; j++)
                    {
                        if (j != i)
                        {
                            //Compare to all except itself
                            comparR = BomberRecall[j];
                            
                            if (comparE.equals(comparR))
                            {
                                //Same contexts
                                if (comparR.getFinalMark() > comparE.getFinalMark())
                                {
                                    //Swap them so that greater one (comparR) is at the end
                                    ContextList tempA = BomberRecall[i];
                                    BomberRecall[i] = BomberRecall[j];
                                    BomberRecall[j] = tempA;

                                    int count = 0;
                                    ContextList[] tempCL = new ContextList[loop - 1];
                                    for (int k = 0; k < loop; k++)
                                    {
                                        //Build new BomberRecall without deleted tree
                                        if (k != i)
                                        {
                                            tempCL[count] = BomberRecall[k];
                                            count++;
                                        }
                                    }

                                    loop = loop - 1;
                                    BomberRecall = null;
                                    BomberRecall = tempCL;
                                    repeat = true;
                                }
                                else if (comparE.getFinalMark() >= comparR.getFinalMark())
                                {
                                    int count = 0;
                                    ContextList[] tempCL = new ContextList[loop - 1];
                                    for (int k = 0; k < loop; k++)
                                    {
                                        //Build new BomberRecall without deleted tree
                                        if (k != j)
                                        {
                                            tempCL[count] = BomberRecall[k];
                                            count++;
                                        }
                                    }

                                    loop = loop - 1;
                                    BomberRecall = null;
                                    BomberRecall = tempCL;
                                    repeat = true;
                                }
                                else
                                {
                                    repeat = false;
                                }
                            }
                        }
                    }
                }
            }
            while (repeat); 
        }
    }
    
    public boolean pushToLongTerm()
    {
        try
        {
            //EDIT WRITING CREDENTIALS TO BEAR MIN
            System.out.println("Now pushing the memory to long term: LongTermMemory.txt");
            
            //Erase old memories
            PrintWriter writer = new PrintWriter(new File("LongTermMemory.txt"));
            writer.print("");
            writer.close();
            
            FileWriter o = new FileWriter("LongTermMemory.txt", true);
            BufferedWriter fw = new BufferedWriter(o);
            
            //Format::
            //Line 0: Number of ContextLists;
            //Line 1: ContextList at i;
            //Line 2: ContextList[i]
            //Line 3: ;
            //Line 4: ContextList at i;
            //ETC. NOTE: Outer delimiter is ";" and inner delimiter is ","
            
            fw.write(loop + ";");
            fw.newLine();
            
            for (int i = 0; i < loop; i++)
            {
                if (BomberRecall[i].toString(true).equals("Error: ContextList is empty"))
                {
                    throw new Throwable("Error: ContextList is empty");
                }
                else
                {
                    fw.write("ContextList:" + i + ";");
                    fw.write(BomberRecall[i].toString(false));
                    
                    if (i+1 != loop)
                    {
                        fw.write(";");
                    }
                }
            }
            
            fw.close();
            o.close();
            
            return true;
        }
        catch (IOException e)
        {
            System.out.println("Error: The was a problem with writing to file LongTermMemory.txt: " + e.toString());
            return false;
        }
        catch (Throwable ex)
        {
            System.out.println("Error: The was a problem with writing to file LongTermMemory.txt: " + ex.toString());
            return false;
        }
    }
    
    public boolean rememberFromLongTerm()
    {
        try
        {
            System.out.print("Now remembering the memory from long term: LongTermMemory.txt, with membrane length of: ");
            
            temp = new String[]{"Iris-setosa", "Iris-versicolor", "Iris-virginica"};
            actions = new Action(temp);
            var = new Integer(0);
            
            fullMarks = 150;
            learningLoop = fullMarks + 1;
            
            this.splitData();
            
            
            Scanner scMem = new Scanner(new File("LongTermMemory.txt")).useDelimiter(";");
            int howMany = scMem.nextInt();
            System.out.print(howMany + "\n");
            loop = howMany;
            
            String _where = "";
            String delay = "";
            String _context = "";
            int _var = 0;
            
            //Edit BomberRecall
            BomberRecall = new ContextList[howMany];
            int atNow = 0;
            
            for(int i = 0; scMem.hasNext(); i++)
            {
                atNow = 0;
                String scCont = scMem.next();
                scCont = scMem.next();
                
                //System.out.println(scCont);
                
                Scanner scLine = new Scanner(scCont).useDelimiter(",");
                while(scLine.hasNext())
                {
                    String l = scLine.next();

                    Scanner scVars = new Scanner(l).useDelimiter(":");
                    
                    _var = scVars.nextInt();
                    _var = scVars.nextInt();
                    
                    if (_var == fullMarks)
                    {
                        //Done, we won!
                        finalMark = 150.00;
                    }
                    else
                    {
                        finalMark = (double) (_var);
                    }
                    
                    scVars = new Scanner(scLine.next()).useDelimiter(":");
                    String _choice = scVars.next();
                    _choice = scVars.next();
                    
                    scVars = new Scanner(scLine.next()).useDelimiter(":");
                    if (_where.equals(""))
                    {
                        //First insert, save where for next use
                        _where = scVars.next();
    
                        scVars.next();
                    }
                    else
                    {
                        //Use previous where
                        if (scLine.hasNext())
                        {
                            delay = scVars.next();
                            scVars.next();
                        }
                    }
                        
                    scVars = new Scanner(scLine.next()).useDelimiter(":");
                    _context = scVars.next();
                    _context = scVars.next();
                    
                    if (atNow == 0)
                    {
                        BomberRecall[i] = new ContextList(new String[][]{{_context, ""}}, _var, actions, _choice);
                    }
                    else
                    {
                        if (_context.equals("NULL"))
                        {
                            _context = "CODEENDOFALL";
                        }
                        BomberRecall[i].insertNode(_where, new String[][]{{_context, ""}}, _var, _choice);
                    }
                    
                    atNow++;
                    if (!delay.equals(""))
                    {
                        _where = delay;
                    }
                }
            }
            
            return true;
        }
        catch (FileNotFoundException e)
        {
            System.out.println("You entered the wrong data type. Please try again. (Original error: '" + e.toString() + "')");
            return false;
        }
    }
    
    public int getLength()
    {
        return loop;
    }

    public double getPrecision()
    {
        double persentage = finalMark / 150.00;
        persentage = persentage * 10000.00;

        int temp = (int) persentage;
        persentage = (double) temp;

        persentage = persentage / 10000.00;

        return persentage;
    }
}