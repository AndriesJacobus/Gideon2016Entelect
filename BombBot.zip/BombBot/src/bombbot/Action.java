package bombbot;

//Small class just to store all the possible operations i.e all the choices the AI has to choose from

public class Action
{
    private String[] operations;

    public Action()
    {
        operations = null;
    }

    public Action(String[] _operations)
    {
        operations = _operations;
    }

    public void setOperations(String[] _operations)
    {
        operations = _operations;
    }
    
    public void addOperation(String operation)
    {
        if (operations == null)
        {
            operations = new String[]{operation};
        }
        else
        {
            String[] tempOpps = new String[operations.length + 1];
            
            System.arraycopy(operations, 0, tempOpps, 0, operations.length);
            
            tempOpps[operations.length] = operation;
            operations = tempOpps;
        }
    }

    public String getOperationAt(int i)
    {
        if (i >= 0 && i < operations.length && operations != null)
        {
            return operations[i];
        }
        else if (operations == null)
        {
            return "Error: Array is null!";
        }
        else
        {
            return "Error: Array index out of bounds!";
        }
    }

    public String[] getAllOperations()
    {
        if (operations == null)
        {
            return (new String[]
            {
                "Error: Array is null!"
            });
        }
        else
        {
            return operations;
        }
    }

    public int getLength()
    {
        return operations.length;
    }
}