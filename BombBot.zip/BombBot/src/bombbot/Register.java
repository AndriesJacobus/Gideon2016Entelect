package bombbot;

/**
 * @author Jaco
 */

//ADD ACCESS FUNCTION FOR IMPLEMENTING PRIORITY / SELF ORDERING LINKED LIST
public class Register
{
    private RegisterNode root;
    private int index;
    
    public Register()
    {
        root = null;
        index = -1;
    }
    
    public Register(String[][] _context, int _var, String _action)
    {
        root = new RegisterNode(new CLNode(_context,_var,_action));
    }
    
    public Register(CLNode ins)
    {
        root = new RegisterNode(ins);
    }
    
    public boolean equals(Register two)
    {
        return (this.index == two.index && checkRegisterNodes(two.getRoot()));
    }
    
    //Checks if two registers have the same nodes IN THE SAME ORDER and with the same FreqScores
    private boolean checkRegisterNodes(RegisterNode twoRoot)
    {
        RegisterNode oneRoot = root;
        
        while (oneRoot.next != null && twoRoot.next != null)
        {
            if (twoRoot.curr.equals(oneRoot.curr))
            {
                oneRoot = oneRoot.next;
                twoRoot = twoRoot.next;
            }
            else
            {
                return false;
            }
        }
        
        return true;
    }
    
    public boolean nodeIsPresent(CLNode search)
    {
        RegisterNode oneRoot = root;
        
        while (oneRoot.next != null)
        {
            if (!oneRoot.curr.equals(search))
            {
                oneRoot = oneRoot.next;
            }
            else
            {
                return true;
            }
        }
        
        return false;
    }
    
    public RegisterNode getRoot()
    {
        return root;
    }
    
    public CLNode getHead()
    {
        return root.curr;
    }
    
    public int getIndex()
    {
        return index;
    }
    
    public void setIndex(int newI)
    {
        if (newI >= 0)
        {
            index = newI;
        }
    }
    
    //pos = left, mid, right
    public void insertRegisterNode(String[][] _context, int _var, String _action)
    {
        RegisterNode search = root;
        
        while (search.next != null)
        {
            search = search.next;
        }
        
        search.next = new RegisterNode(new CLNode(_context, _var, _action));
    }
    
    public CLNode[] getAllNodes()
    {
        RegisterNode temp = root;
        int counter;
        
        for (counter = 0; temp.curr != null; counter++)
        {
            if (temp.next != null)
            {
                temp = temp.next;
            }
        }
        
        CLNode[] all = new CLNode[counter];
        temp = root;
        
        for (int i = 0; temp.curr != null; i++)
        {
            all[i] = temp.curr;
            
            if (temp.next != null)
            {
                temp = temp.next;
            }
        }
        
        return all;
    }
    
    private class RegisterNode
    {
        public RegisterNode next = null;
        public CLNode curr = null;
        //add int of max accumilitive weight of children
         
        public RegisterNode(CLNode ins)
        {
            curr = ins;
        }
    }
}
