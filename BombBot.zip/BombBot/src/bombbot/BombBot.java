package bombbot;

//import java.nio.file.Path;
//import java.nio.file.Paths;
//import java.util.Scanner;
import java.io.BufferedReader;
import java.io.File;
import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.FileWriter;
import java.io.IOException;
import java.io.InputStreamReader;
import java.util.logging.Level;
import java.util.logging.Logger;

/**
 * @author Jaco
 */

public class BombBot
{    
    private static void runMiniMaxEngine(String botKey, String botDir)
    {
        String line, map, playerStats;
        int lvl;
        //int reward = -1;     //Possible AI reward function = r(x) = Points + (1 / BlastRadius)
        
        //Fast method for file string extraction
        try
        {
//            BufferedReader reader = new BufferedReader(new InputStreamReader(new FileInputStream(new File(botDir + File.separator + "map.txt"))));
            BufferedReader reader = new BufferedReader(new InputStreamReader(new FileInputStream("error.txt")));
            
            //Get round num => used to set MiniMaxEngine's root node's lvl
            line = reader.readLine();       //get info line
            String[] tempT = line.split(", ");
            lvl = Integer.parseInt(tempT[2].substring(15, tempT[2].length()));
            
            //Read map:
            map = reader.readLine();        //skip first "###..." line
            playerStats = "";
            
            while ((line = reader.readLine()) != null)
            {
                //Continue reading map:
                if (line.charAt(0) == '#')
                {
                    map += "\n" + line;
                }
                else
                {
                    playerStats += reader.readLine() + "\n";
                    line = reader.readLine();
                    playerStats += line + "\n";
                            
                    if (line.substring(5, line.length()).equals(botKey))
                    {
                        //log Points
                        line = reader.readLine();
                        
                        playerStats += line + "\n";
                        
                        for (int i = 0; i < 4; i++)
                        {
                            playerStats += reader.readLine() + "\n";
                        }
                    }
                    else
                    {                    
                        for (int i = 0; i < 5; i++)
                        {
                            playerStats += reader.readLine() + "\n";
                        }
                    }
                    
                    reader.readLine();      //skip one "---..." line
                }
            }
            
            reader.close();
            
//            System.out.println(map + "\nReward: " + reward + "\nPlayer stats:\n" + playerStats);      //check that info was read correctly
            
            //Engage MiniMax with map and reward
            MiniMaxEnigine vEight = new MiniMaxEnigine(map, playerStats, botKey.charAt(0), lvl);
            
            //Make move
            File move = new File(botDir + File.separator + "move.txt");
//            File move = new File("move.txt");
            
            FileWriter writeR = new FileWriter(move);
            writeR.write(String.valueOf(vEight.getBestAction()));
            
            writeR.close();
        }
        catch (IOException ex)
        {
            Logger.getLogger(BombBot.class.getName()).log(Level.SEVERE, null, ex);
        }
    }
    
    public static void main(String... args) throws FileNotFoundException, IOException
    {
        //Screen in input, var is award, Action is choices available

        double startTime = System.nanoTime();
//        
//        System.out.println("TESTING TEST CASE ONE:");
//        testOne();
//        System.out.println("============================================================");
//        
//        System.out.println("TESTING TEST CASE TWO:");
//        testTwo();
//        System.out.println("============================================================");
        
        //BOT FILE IO
        //Run with server:
//        String botKey = args[0];
//        String botDir = args[1].replace("\"", "");
//        
//        System.out.println("Bot Key: " + botKey);
//        System.out.println("Bot Dir: " + botDir);
//        
//        runMiniMaxEngine(botKey, botDir);
        
//        Run from home examp:
        runMiniMaxEngine("A", "");
                
        //STATS
//        System.out.println("\nThe program executed with a final precision of: " + (double) (one.getPrecision() * 100.00) + "%!");
//
        double durationNano = System.nanoTime() - startTime;
        double durationSec = durationNano / 1000000000;

        System.out.println("The total running time is: " + durationSec + "s or precisely " + (long) durationNano + "Ns (" + (long) (durationNano / 1000000) + " Miliseconds).");

        //System.exit(0);
    }
}

//SAMPLE BOT
//import java.io.File;
//import java.io.FileWriter;
//import java.io.IOException;
//import java.nio.charset.Charset;
//import java.nio.file.Files;
//import java.nio.file.Path;
//import java.nio.file.Paths;
//import java.util.List;
//import java.util.Random;
//
///**
// * Created by hennie.brink on 2016/02/07.
// */
//
//public class Main
//{
//    public static void main(String... args)
//    {
//        String botKey = args[0];
//        String botDir = args[1].replace("\"", "");
//
//        System.out.println("Bot Key: " + botKey);
//        System.out.println("Bot Dir: " + botDir);
//
//        Path path = Paths.get(botDir + File.separator + "state.json");
//
//        File move = new File(botDir + File.separator + "move.txt");
//        try
//        {
//            List<String> lines = Files.readAllLines(path, Charset.defaultCharset());
//
//            StringBuilder fileContent = new StringBuilder();
//            for (String line : lines)
//            {
//                fileContent.append(line);
//            }
//
//            if (move.createNewFile())
//            {
//                FileWriter write = new FileWriter(move);
//                write.write(String.valueOf(new Random().nextInt(7)));
//                write.close();
//            }
//        }
//        catch (IOException e)
//        {
//            e.printStackTrace();
//        }
//    }
//}