/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
package bombbot;

import org.junit.After;
import org.junit.AfterClass;
import org.junit.Before;
import org.junit.BeforeClass;
import org.junit.Test;
import static org.junit.Assert.*;

/**
 *
 * @author Jaco
 */
public class BombBotTest
{
    
    public BombBotTest()
    {
    }
    
    @BeforeClass
    public static void setUpClass()
    {
    }
    
    @AfterClass
    public static void tearDownClass()
    {
    }
    
    @Before
    public void setUp()
    {
    }
    
    @After
    public void tearDown()
    {
    }

    /**
     * Test of testOne method, of class BombBot.
     */
    @Test
    public void testTestOne()
    {
        System.out.println("testOne");
        BombBot.testOne();
        // TODO review the generated test code and remove the default call to fail.
        fail("The test case is a prototype.");
    }

    /**
     * Test of testTwo method, of class BombBot.
     */
    @Test
    public void testTestTwo()
    {
        System.out.println("testTwo");
        BombBot.testTwo();
        // TODO review the generated test code and remove the default call to fail.
        fail("The test case is a prototype.");
    }

    /**
     * Test of main method, of class BombBot.
     */
    @Test
    public void testMain()
    {
        System.out.println("main");
        String[] args = null;
        BombBot.main(args);
        // TODO review the generated test code and remove the default call to fail.
        fail("The test case is a prototype.");
    }
}